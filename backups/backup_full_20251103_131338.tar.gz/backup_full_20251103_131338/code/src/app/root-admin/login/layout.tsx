// Login page should not have admin layout
export default function LoginLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
